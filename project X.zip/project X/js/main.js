// Main JavaScript functionality
class EgyptAdventures {
    constructor() {
        this.init();
    }

    init() {
        this.initializeComponents();
        this.bindEvents();
        this.setupIntersectionObserver();
    }

    initializeComponents() {
        this.navigation = new Navigation();
        this.heroSlider = new HeroSlider();
        this.gallery = new Gallery();
        this.translator = new Translator();
        this.bookingSystem = new BookingSystem();
        this.chatWidget = new ChatWidget();
    }

    bindEvents() {
        window.addEventListener('load', () => this.handlePageLoad());
        window.addEventListener('scroll', () => this.handleScroll());
        document.addEventListener('DOMContentLoaded', () => this.handleDOMReady());
    }

    handlePageLoad() {
        document.body.classList.add('loaded');
        this.preloader.hide();
    }

    handleScroll() {
        this.navigation.handleScroll();
        this.parallaxElements();
    }

    handleDOMReady() {
        this.initializeAnimations();
        this.setupForms();
        this.loadDynamicContent();
    }

    setupIntersectionObserver() {
        const options = {
            root: null,
            threshold: 0.1,
            rootMargin: '0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('in-view');
                    if (entry.target.dataset.animate) {
                        entry.target.classList.add(entry.target.dataset.animate);
                    }
                }
            });
        }, options);

        document.querySelectorAll('.animate-on-scroll').forEach(el => {
            observer.observe(el);
        });
    }

    parallaxElements() {
        const parallaxElements = document.querySelectorAll('.parallax');
        parallaxElements.forEach(element => {
            const speed = element.dataset.speed || 0.5;
            const yPos = -(window.pageYOffset * speed);
            element.style.transform = `translateY(${yPos}px)`;
        });
    }
}

class Navigation {
    constructor() {
        this.nav = document.getElementById('mainNav');
        this.mobileToggle = document.querySelector('.mobile-menu-toggle');
        this.navLinks = document.querySelector('.nav-links');
        this.bindEvents();
    }

    bindEvents() {
        this.mobileToggle.addEventListener('click', () => this.toggleMobileMenu());
        window.addEventListener('resize', () => this.handleResize());
    }

    toggleMobileMenu() {
        this.navLinks.classList.toggle('active');
        this.mobileToggle.classList.toggle('active');
    }

    handleScroll() {
        if (window.pageYOffset > 100) {
            this.nav.classList.add('nav-scrolled');
        } else {
            this.nav.classList.remove('nav-scrolled');
        }
    }

    handleResize() {
        if (window.innerWidth > 992) {
            this.navLinks.classList.remove('active');
            this.mobileToggle.classList.remove('active');
        }
    }
}

class HeroSlider {
    constructor() {
        this.slides = document.querySelectorAll('.hero-slide');
        this.dots = document.querySelector('.hero-dots');
        this.prevBtn = document.querySelector('.prev-slide');
        this.nextBtn = document.querySelector('.next-slide');
        this.currentSlide = 0;
        this.slideInterval = null;
        this.init();
    }

    init() {
        this.createDots();
        this.bindEvents();
        this.startAutoSlide();
        this.updateSlides();
    }

    createDots() {
        this.slides.forEach((_, index) => {
            const dot = document.createElement('button');
            dot.classList.add('hero-dot');
            dot.addEventListener('click', () => this.goToSlide(index));
            this.dots.appendChild(dot);
        });
    }

    bindEvents() {
        this.prevBtn.addEventListener('click', () => this.prevSlide());
        this.nextBtn.addEventListener('click', () => this.nextSlide());
    }

    updateSlides() {
        this.slides.forEach((slide, index) => {
            slide.classList.remove('active');
            if (index === this.currentSlide) {
                slide.classList.add('active');
            }
        });

        this.updateDots();
    }

    updateDots() {
        const dots = this.dots.querySelectorAll('.hero-dot');
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === this.currentSlide);
        });
    }

    nextSlide() {
        this.currentSlide = (this.currentSlide + 1) % this.slides.length;
        this.updateSlides();
    }

    prevSlide() {
        this.currentSlide = (this.currentSlide - 1 + this.slides.length) % this.slides.length;
        this.updateSlides();
    }

    goToSlide(index) {
        this.currentSlide = index;
        this.updateSlides();
    }

    startAutoSlide() {
        this.slideInterval = setInterval(() => this.nextSlide(), 5000);
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    window.egyptAdventures = new EgyptAdventures();
}); 
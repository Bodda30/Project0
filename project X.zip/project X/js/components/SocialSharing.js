class SocialSharing {
    constructor() {
        this.shareButtons = {
            facebook: {
                icon: '📘',
                label: 'Facebook',
                shareUrl: 'https://www.facebook.com/sharer/sharer.php?u='
            },
            twitter: {
                icon: '🐦',
                label: 'Twitter',
                shareUrl: 'https://twitter.com/intent/tweet?url='
            },
            whatsapp: {
                icon: '📱',
                label: 'WhatsApp',
                shareUrl: 'https://wa.me/?text='
            },
            email: {
                icon: '📧',
                label: 'Email',
                shareUrl: 'mailto:?body='
            },
            copy: {
                icon: '📋',
                label: 'Copy Link'
            }
        };

        this.init();
    }

    init() {
        this.createShareUI();
        this.bindEvents();
    }

    createShareUI() {
        const template = `
            <div class="share-modal" id="shareModal">
                <div class="share-content">
                    <h3>Share This Tour</h3>
                    <div class="share-buttons">
                        ${Object.entries(this.shareButtons)
                            .map(([key, value]) => `
                                <button class="share-button" data-platform="${key}">
                                    <span class="share-icon">${value.icon}</span>
                                    <span class="share-label">${value.label}</span>
                                </button>
                            `).join('')}
                    </div>
                    <div class="share-link">
                        <input type="text" readonly value="${window.location.href}">
                        <button class="copy-link">Copy</button>
                    </div>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', template);
    }

    bindEvents() {
        document.querySelectorAll('.share-button').forEach(button => {
            button.addEventListener('click', (e) => {
                const platform = e.currentTarget.dataset.platform;
                this.share(platform);
            });
        });

        document.querySelector('.copy-link').addEventListener('click', () => {
            this.copyToClipboard();
        });

        // Close modal when clicking outside
        document.getElementById('shareModal').addEventListener('click', (e) => {
            if (e.target.id === 'shareModal') {
                this.closeModal();
            }
        });
    }

    share(platform) {
        const url = encodeURIComponent(window.location.href);
        const title = encodeURIComponent(document.title);
        const shareButton = this.shareButtons[platform];

        if (platform === 'copy') {
            this.copyToClipboard();
            return;
        }

        const shareUrl = `${shareButton.shareUrl}${url}&title=${title}`;
        window.open(shareUrl, '_blank');
    }

    async copyToClipboard() {
        const input = document.querySelector('.share-link input');
        
        try {
            await navigator.clipboard.writeText(input.value);
            this.showToast('Link copied to clipboard!');
        } catch (err) {
            this.showToast('Failed to copy link', 'error');
        }
    }

    showModal() {
        document.getElementById('shareModal').classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    closeModal() {
        document.getElementById('shareModal').classList.remove('active');
        document.body.style.overflow = '';
    }

    showToast(message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        document.body.appendChild(toast);

        setTimeout(() => {
            toast.classList.add('show');
        }, 100);

        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
} 
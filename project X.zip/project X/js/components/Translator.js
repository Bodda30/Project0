class Translator {
    constructor() {
        this.currentLanguage = 'en';
        this.translations = {};
        this.init();
    }

    async init() {
        await this.loadTranslations();
        this.bindEvents();
        this.setInitialLanguage();
    }

    async loadTranslations() {
        try {
            const response = await fetch('/api/translations');
            this.translations = await response.json();
        } catch (error) {
            console.error('Failed to load translations:', error);
        }
    }

    bindEvents() {
        const languageSelect = document.getElementById('languageSelect');
        if (languageSelect) {
            languageSelect.addEventListener('change', (e) => {
                this.changeLanguage(e.target.value);
            });
        }
    }

    setInitialLanguage() {
        const savedLanguage = localStorage.getItem('preferredLanguage');
        const browserLanguage = navigator.language.split('-')[0];
        const initialLanguage = savedLanguage || browserLanguage || 'en';
        this.changeLanguage(initialLanguage);
    }

    changeLanguage(language) {
        this.currentLanguage = language;
        localStorage.setItem('preferredLanguage', language);
        document.documentElement.lang = language;
        document.documentElement.dir = this.isRTL(language) ? 'rtl' : 'ltr';
        this.updateContent();
    }

    isRTL(language) {
        const rtlLanguages = ['ar', 'he', 'fa'];
        return rtlLanguages.includes(language);
    }

    updateContent() {
        document.querySelectorAll('[data-translate]').forEach(element => {
            const key = element.dataset.translate;
            if (this.translations[this.currentLanguage]?.[key]) {
                element.textContent = this.translations[this.currentLanguage][key];
            }
        });

        document.querySelectorAll('[data-translate-placeholder]').forEach(element => {
            const key = element.dataset.translatePlaceholder;
            if (this.translations[this.currentLanguage]?.[key]) {
                element.placeholder = this.translations[this.currentLanguage][key];
            }
        });
    }

    translate(key, params = {}) {
        let text = this.translations[this.currentLanguage]?.[key] || key;
        Object.entries(params).forEach(([param, value]) => {
            text = text.replace(`{${param}}`, value);
        });
        return text;
    }
} 
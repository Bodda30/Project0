class BookingSystem {
    constructor() {
        this.form = document.querySelector('.booking-form');
        this.init();
    }

    init() {
        if (this.form) {
            this.bindEvents();
            this.setupDatePickers();
            this.setupGuestCounter();
            this.setupPriceCalculator();
        }
    }

    bindEvents() {
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
        
        // Real-time validation
        this.form.querySelectorAll('input, select').forEach(input => {
            input.addEventListener('input', () => this.validateField(input));
        });
    }

    setupDatePickers() {
        const dateInputs = this.form.querySelectorAll('input[type="date"]');
        dateInputs.forEach(input => {
            // Set min date to today
            const today = new Date().toISOString().split('T')[0];
            input.min = today;

            // Set max date to 1 year from now
            const maxDate = new Date();
            maxDate.setFullYear(maxDate.getFullYear() + 1);
            input.max = maxDate.toISOString().split('T')[0];
        });
    }

    setupGuestCounter() {
        const guestInput = this.form.querySelector('#guests');
        if (guestInput) {
            const counter = document.createElement('div');
            counter.className = 'guest-counter';
            counter.innerHTML = `
                <button type="button" class="decrease">-</button>
                <span class="count">${guestInput.value}</span>
                <button type="button" class="increase">+</button>
            `;

            guestInput.parentNode.appendChild(counter);

            counter.querySelector('.decrease').addEventListener('click', () => {
                const currentValue = parseInt(guestInput.value);
                if (currentValue > 1) {
                    guestInput.value = currentValue - 1;
                    counter.querySelector('.count').textContent = guestInput.value;
                    this.updatePrice();
                }
            });

            counter.querySelector('.increase').addEventListener('click', () => {
                const currentValue = parseInt(guestInput.value);
                if (currentValue < 20) {
                    guestInput.value = currentValue + 1;
                    counter.querySelector('.count').textContent = guestInput.value;
                    this.updatePrice();
                }
            });
        }
    }

    setupPriceCalculator() {
        const tourSelect = this.form.querySelector('#tourSelect');
        const guestInput = this.form.querySelector('#guests');
        
        if (tourSelect && guestInput) {
            [tourSelect, guestInput].forEach(input => {
                input.addEventListener('change', () => this.updatePrice());
            });
        }
    }

    updatePrice() {
        const tourSelect = this.form.querySelector('#tourSelect');
        const guestInput = this.form.querySelector('#guests');
        const priceDisplay = document.querySelector('.total-price');

        if (tourSelect && guestInput && priceDisplay) {
            const basePrice = parseFloat(tourSelect.selectedOptions[0].dataset.price);
            const guests = parseInt(guestInput.value);
            const total = basePrice * guests;
            priceDisplay.textContent = `$${total.toFixed(2)}`;
        }
    }

    async handleSubmit(e) {
        e.preventDefault();

        if (!this.validateForm()) {
            return;
        }

        const formData = new FormData(this.form);
        const bookingData = Object.fromEntries(formData.entries());

        try {
            this.showLoadingState();
            const response = await this.submitBooking(bookingData);
            
            if (response.success) {
                this.showSuccessMessage();
                this.redirectToPayment(response.bookingId);
            } else {
                this.showErrorMessage(response.message);
            }
        } catch (error) {
            this.showErrorMessage('An error occurred. Please try again.');
        } finally {
            this.hideLoadingState();
        }
    }

    validateForm() {
        let isValid = true;
        this.form.querySelectorAll('input, select').forEach(input => {
            if (!this.validateField(input)) {
                isValid = false;
            }
        });
        return isValid;
    }

    validateField(input) {
        const value = input.value.trim();
        let isValid = true;
        const errorElement = this.getErrorElement(input);

        switch (input.type) {
            case 'email':
                isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
                break;
            case 'tel':
                isValid = /^\+?[\d\s-]{8,}$/.test(value);
                break;
            case 'date':
                const selectedDate = new Date(value);
                const today = new Date();
                isValid = selectedDate >= today;
                break;
            default:
                isValid = value.length > 0;
        }

        input.classList.toggle('invalid', !isValid);
        errorElement.textContent = isValid ? '' : this.getErrorMessage(input);
        return isValid;
    }

    getErrorElement(input) {
        let errorElement = input.parentNode.querySelector('.error-message');
        if (!errorElement) {
            errorElement = document.createElement('div');
            errorElement.className = 'error-message';
            input.parentNode.appendChild(errorElement);
        }
        return errorElement;
    }

    getErrorMessage(input) {
        const messages = {
            email: 'Please enter a valid email address',
            tel: 'Please enter a valid phone number',
            date: 'Please select a future date',
            default: 'This field is required'
        };
        return messages[input.type] || messages.default;
    }

    async submitBooking(bookingData) {
        const response = await fetch('/api/bookings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(bookingData)
        });
        return await response.json();
    }

    showLoadingState() {
        const submitButton = this.form.querySelector('button[type="submit"]');
        submitButton.disabled = true;
        submitButton.innerHTML = '<span class="loading-spinner"></span> Processing...';
    }

    hideLoadingState() {
        const submitButton = this.form.querySelector('button[type="submit"]');
        submitButton.disabled = false;
        submitButton.textContent = 'Book Now';
    }

    showSuccessMessage() {
        const message = document.createElement('div');
        message.className = 'success-message';
        message.textContent = 'Booking successful! Redirecting to payment...';
        this.form.appendChild(message);
    }

    showErrorMessage(text) {
        const message = document.createElement('div');
        message.className = 'error-message';
        message.textContent = text;
        this.form.appendChild(message);
        setTimeout(() => message.remove(), 5000);
    }

    redirectToPayment(bookingId) {
        setTimeout(() => {
            window.location.href = `/payment.html?booking=${bookingId}`;
        }, 2000);
    }
} 
class ReviewSystem {
    constructor(tourId) {
        this.tourId = tourId;
        this.reviews = [];
        this.currentPage = 1;
        this.perPage = 5;
        this.init();
    }

    async init() {
        this.createReviewUI();
        await this.loadReviews();
        this.bindEvents();
    }

    createReviewUI() {
        const template = `
            <section class="reviews-section">
                <h3>Customer Reviews</h3>
                <div class="review-stats">
                    <div class="average-rating">
                        <span class="big-rating">0.0</span>
                        <div class="stars"></div>
                        <span class="total-reviews">(0 reviews)</span>
                    </div>
                    <div class="rating-breakdown"></div>
                </div>
                
                <div class="review-form-container">
                    <button class="write-review-btn">Write a Review</button>
                    <form class="review-form hidden">
                        <div class="rating-input">
                            <label>Your Rating</label>
                            <div class="star-input">
                                ${Array(5).fill().map((_, i) => `
                                    <input type="radio" name="rating" value="${5-i}" id="star${5-i}">
                                    <label for="star${5-i}">★</label>
                                `).join('')}
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="reviewTitle">Title</label>
                            <input type="text" id="reviewTitle" required maxlength="100">
                        </div>
                        <div class="form-group">
                            <label for="reviewContent">Your Review</label>
                            <textarea id="reviewContent" required maxlength="1000"></textarea>
                            <span class="char-count">1000 characters remaining</span>
                        </div>
                        <div class="form-group">
                            <label for="reviewPhotos">Add Photos</label>
                            <input type="file" id="reviewPhotos" multiple accept="image/*">
                            <div class="photo-preview"></div>
                        </div>
                        <button type="submit" class="submit-review">Submit Review</button>
                    </form>
                </div>

                <div class="reviews-list"></div>
                <div class="reviews-pagination"></div>
            </section>
        `;

        document.querySelector('.tour-details').insertAdjacentHTML('beforeend', template);
    }

    async loadReviews() {
        try {
            const response = await fetch(`/api/tours/${this.tourId}/reviews?page=${this.currentPage}`);
            const data = await response.json();
            this.reviews = data.reviews;
            this.totalReviews = data.total;
            this.averageRating = data.averageRating;
            this.ratingBreakdown = data.ratingBreakdown;

            this.updateReviewStats();
            this.renderReviews();
            this.updatePagination();
        } catch (error) {
            console.error('Error loading reviews:', error);
        }
    }

    updateReviewStats() {
        const statsSection = document.querySelector('.review-stats');
        statsSection.querySelector('.big-rating').textContent = this.averageRating.toFixed(1);
        statsSection.querySelector('.total-reviews').textContent = `(${this.totalReviews} reviews)`;

        // Update rating breakdown
        const breakdown = document.querySelector('.rating-breakdown');
        breakdown.innerHTML = Object.entries(this.ratingBreakdown)
            .map(([rating, count]) => {
                const percentage = (count / this.totalReviews) * 100;
                return `
                    <div class="rating-bar">
                        <span>${rating} stars</span>
                        <div class="bar">
                            <div class="fill" style="width: ${percentage}%"></div>
                        </div>
                        <span>${count}</span>
                    </div>
                `;
            }).join('');
    }

    renderReviews() {
        const reviewsList = document.querySelector('.reviews-list');
        reviewsList.innerHTML = this.reviews.map(review => this.createReviewCard(review)).join('');
    }

    createReviewCard(review) {
        return `
            <div class="review-card" data-review-id="${review.id}">
                <div class="review-header">
                    <div class="reviewer-info">
                        <img src="${review.user.avatar}" alt="${review.user.name}" class="reviewer-avatar">
                        <div>
                            <h4>${review.user.name}</h4>
                            <span class="review-date">${new Date(review.date).toLocaleDateString()}</span>
                        </div>
                    </div>
                    <div class="review-rating">
                        ${this.getStarRating(review.rating)}
                    </div>
                </div>
                <h5 class="review-title">${review.title}</h5>
                <p class="review-content">${review.content}</p>
                ${review.photos ? this.createPhotoGallery(review.photos) : ''}
                <div class="review-actions">
                    <button class="helpful-btn" data-helpful="${review.helpful}">
                        <span class="icon">👍</span> Helpful (${review.helpful})
                    </button>
                    <button class="share-btn">
                        <span class="icon">📤</span> Share
                    </button>
                    <button class="report-btn">
                        <span class="icon">⚠️</span> Report
                    </button>
                </div>
            </div>
        `;
    }

    createPhotoGallery(photos) {
        return `
            <div class="review-photos">
                ${photos.map(photo => `
                    <div class="photo-thumbnail">
                        <img src="${photo.thumbnail}" alt="Review photo" 
                             data-full="${photo.full}" onclick="openPhotoViewer(this)">
                    </div>
                `).join('')}
            </div>
        `;
    }

    getStarRating(rating) {
        return `
            <div class="stars">
                ${Array(5).fill().map((_, i) => `
                    <span class="star ${i < rating ? 'filled' : ''}">★</span>
                `).join('')}
            </div>
        `;
    }

    updatePagination() {
        const totalPages = Math.ceil(this.totalReviews / this.perPage);
        const pagination = document.querySelector('.reviews-pagination');
        
        pagination.innerHTML = `
            <button class="prev-page" ${this.currentPage === 1 ? 'disabled' : ''}>
                Previous
            </button>
            <div class="page-numbers">
                ${this.generatePageNumbers(totalPages)}
            </div>
            <button class="next-page" ${this.currentPage === totalPages ? 'disabled' : ''}>
                Next
            </button>
        `;
    }

    generatePageNumbers(totalPages) {
        let pages = [];
        for (let i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= this.currentPage - 1 && i <= this.currentPage + 1)) {
                pages.push(`
                    <button class="page-number ${i === this.currentPage ? 'active' : ''}" 
                            data-page="${i}">
                        ${i}
                    </button>
                `);
            } else if (i === this.currentPage - 2 || i === this.currentPage + 2) {
                pages.push('<span class="page-dots">...</span>');
            }
        }
        return pages.join('');
    }

    bindEvents() {
        // Review form events
        const form = document.querySelector('.review-form');
        const writeBtn = document.querySelector('.write-review-btn');
        
        writeBtn.addEventListener('click', () => {
            form.classList.toggle('hidden');
            writeBtn.classList.toggle('hidden');
        });

        form.addEventListener('submit', (e) => this.handleReviewSubmit(e));

        // Character count
        const textarea = document.getElementById('reviewContent');
        textarea.addEventListener('input', (e) => {
            const remaining = 1000 - e.target.value.length;
            form.querySelector('.char-count').textContent = `${remaining} characters remaining`;
        });

        // Photo upload preview
        const photoInput = document.getElementById('reviewPhotos');
        photoInput.addEventListener('change', (e) => this.handlePhotoUpload(e));

        // Pagination events
        document.querySelector('.reviews-pagination').addEventListener('click', (e) => {
            if (e.target.classList.contains('page-number')) {
                this.currentPage = parseInt(e.target.dataset.page);
                this.loadReviews();
            } else if (e.target.classList.contains('prev-page')) {
                this.currentPage--;
                this.loadReviews();
            } else if (e.target.classList.contains('next-page')) {
                this.currentPage++;
                this.loadReviews();
            }
        });

        // Review action events
        document.querySelector('.reviews-list').addEventListener('click', (e) => {
            const reviewCard = e.target.closest('.review-card');
            if (!reviewCard) return;

            if (e.target.classList.contains('helpful-btn')) {
                this.handleHelpfulClick(reviewCard.dataset.reviewId);
            } else if (e.target.classList.contains('share-btn')) {
                this.handleShareClick(reviewCard.dataset.reviewId);
            } else if (e.target.classList.contains('report-btn')) {
                this.handleReportClick(reviewCard.dataset.reviewId);
            }
        });
    }

    async handleReviewSubmit(e) {
        e.preventDefault();
        const form = e.target;
        const formData = new FormData(form);

        try {
            const response = await fetch(`/api/tours/${this.tourId}/reviews`, {
                method: 'POST',
                body: formData
            });

            if (response.ok) {
                this.showSuccess('Review submitted successfully!');
                form.reset();
                form.classList.add('hidden');
                document.querySelector('.write-review-btn').classList.remove('hidden');
                await this.loadReviews();
            } else {
                throw new Error('Failed to submit review');
            }
        } catch (error) {
            this.showError('Failed to submit review. Please try again.');
        }
    }

    handlePhotoUpload(e) {
        const files = Array.from(e.target.files);
        const preview = document.querySelector('.photo-preview');
        preview.innerHTML = '';

        files.forEach(file => {
            const reader = new FileReader();
            reader.onload = (e) => {
                preview.insertAdjacentHTML('beforeend', `
                    <div class="preview-thumbnail">
                        <img src="${e.target.result}" alt="Preview">
                        <button type="button" class="remove-photo">×</button>
                    </div>
                `);
            };
            reader.readAsDataURL(file);
        });
    }

    async handleHelpfulClick(reviewId) {
        try {
            const response = await fetch(`/api/reviews/${reviewId}/helpful`, {
                method: 'POST'
            });
            if (response.ok) {
                await this.loadReviews();
            }
        } catch (error) {
            this.showError('Failed to mark review as helpful');
        }
    }

    handleShareClick(reviewId) {
        const shareData = {
            title: 'Tour Review',
            text: 'Check out this review!',
            url: `${window.location.origin}/tours/${this.tourId}?review=${reviewId}`
        };

        if (navigator.share) {
            navigator.share(shareData);
        } else {
            // Fallback to copy link
            navigator.clipboard.writeText(shareData.url);
            this.showSuccess('Link copied to clipboard!');
        }
    }

    handleReportClick(reviewId) {
        // Implement report modal
    }

    showSuccess(message) {
        // Implement success toast
    }

    showError(message) {
        // Implement error toast
    }
} 
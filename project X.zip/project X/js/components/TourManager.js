class TourManager {
    constructor() {
        this.tours = [];
        this.filteredTours = [];
        this.filters = {
            type: 'all',
            duration: 'all',
            maxPrice: 1000,
            rating: 0
        };
        this.init();
    }

    async init() {
        await this.loadTours();
        this.setupFilters();
        this.bindEvents();
        this.renderTours();
    }

    async loadTours() {
        try {
            const response = await fetch('/api/tours');
            this.tours = await response.json();
            this.filteredTours = [...this.tours];
        } catch (error) {
            console.error('Error loading tours:', error);
            this.showError('Failed to load tours. Please try again later.');
        }
    }

    setupFilters() {
        // Tour Type Filter
        const typeSelect = document.getElementById('tourType');
        typeSelect.addEventListener('change', (e) => {
            this.filters.type = e.target.value;
            this.applyFilters();
        });

        // Duration Filter
        const durationSelect = document.getElementById('duration');
        durationSelect.addEventListener('change', (e) => {
            this.filters.duration = e.target.value;
            this.applyFilters();
        });

        // Price Range Filter
        const priceRange = document.getElementById('priceRange');
        const rangeValue = document.querySelector('.range-value');
        priceRange.addEventListener('input', (e) => {
            const value = e.target.value;
            this.filters.maxPrice = value;
            rangeValue.textContent = `$${value}`;
            this.applyFilters();
        });

        // Rating Filter
        const ratingInputs = document.querySelectorAll('input[name="rating"]');
        ratingInputs.forEach(input => {
            input.addEventListener('change', (e) => {
                this.filters.rating = parseInt(e.target.value);
                this.applyFilters();
            });
        });
    }

    bindEvents() {
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('book-tour')) {
                const tourId = e.target.closest('.tour-card').dataset.tourId;
                this.handleBooking(tourId);
            }
        });
    }

    applyFilters() {
        this.filteredTours = this.tours.filter(tour => {
            const typeMatch = this.filters.type === 'all' || tour.type === this.filters.type;
            const durationMatch = this.filters.duration === 'all' || this.matchDuration(tour.duration, this.filters.duration);
            const priceMatch = tour.price <= this.filters.maxPrice;
            const ratingMatch = this.filters.rating === 0 || tour.rating >= this.filters.rating;

            return typeMatch && durationMatch && priceMatch && ratingMatch;
        });

        this.renderTours();
    }

    matchDuration(tourDuration, filterDuration) {
        const days = parseInt(tourDuration);
        switch(filterDuration) {
            case '1': return days === 1;
            case '2-3': return days >= 2 && days <= 3;
            case '4-7': return days >= 4 && days <= 7;
            case '8+': return days >= 8;
            default: return true;
        }
    }

    renderTours() {
        const grid = document.querySelector('.grid');
        const template = document.getElementById('tourCardTemplate');
        
        grid.innerHTML = '';

        if (this.filteredTours.length === 0) {
            grid.innerHTML = `
                <div class="no-results">
                    <h3>No tours found</h3>
                    <p>Try adjusting your filters to see more results.</p>
                </div>
            `;
            return;
        }

        this.filteredTours.forEach(tour => {
            const card = template.content.cloneNode(true);
            
            // Set tour data
            card.querySelector('.tour-card').dataset.tourId = tour.id;
            card.querySelector('.tour-image img').src = tour.image;
            card.querySelector('.tour-image img').alt = tour.title;
            card.querySelector('.badge-type').textContent = tour.type;
            card.querySelector('.badge-featured').style.display = tour.featured ? 'block' : 'none';
            card.querySelector('.tour-title').textContent = tour.title;
            card.querySelector('.duration').textContent = `${tour.duration} days`;
            card.querySelector('.group-size').textContent = `${tour.groupSize} people max`;
            card.querySelector('.tour-description').textContent = tour.description;
            card.querySelector('.price').textContent = `$${tour.price}`;

            // Add features
            const featuresContainer = card.querySelector('.tour-features');
            tour.features.forEach(feature => {
                const featureEl = document.createElement('span');
                featureEl.className = 'feature';
                featureEl.innerHTML = `<span class="icon">${feature.icon}</span>${feature.text}`;
                featuresContainer.appendChild(featureEl);
            });

            grid.appendChild(card);
        });
    }

    async handleBooking(tourId) {
        try {
            // Check if user is logged in
            const isLoggedIn = await this.checkAuthStatus();
            
            if (!isLoggedIn) {
                this.showLoginPrompt();
                return;
            }

            const tour = this.tours.find(t => t.id === tourId);
            if (!tour) {
                throw new Error('Tour not found');
            }

            // Redirect to booking page with tour details
            window.location.href = `/booking.html?tour=${tourId}`;

        } catch (error) {
            console.error('Booking error:', error);
            this.showError('Failed to process booking. Please try again.');
        }
    }

    async checkAuthStatus() {
        try {
            const response = await fetch('/api/auth/status');
            const data = await response.json();
            return data.isLoggedIn;
        } catch (error) {
            return false;
        }
    }

    showLoginPrompt() {
        // Implementation of login modal or redirect to login page
    }

    showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        document.querySelector('.tours-page').prepend(errorDiv);
        setTimeout(() => errorDiv.remove(), 5000);
    }
} 
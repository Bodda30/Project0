class Gallery {
    constructor() {
        this.gallery = document.querySelector('.gallery-grid');
        this.lightbox = this.createLightbox();
        this.currentIndex = 0;
        this.images = [];
        this.init();
    }

    init() {
        this.loadGalleryImages();
        this.bindEvents();
        this.setupFilters();
    }

    createLightbox() {
        const lightbox = document.createElement('div');
        lightbox.className = 'lightbox';
        lightbox.innerHTML = `
            <div class="lightbox-content">
                <button class="close-lightbox">×</button>
                <button class="prev-image">❮</button>
                <button class="next-image">❯</button>
                <img src="" alt="">
                <div class="lightbox-caption"></div>
                <div class="lightbox-counter"></div>
            </div>
        `;
        document.body.appendChild(lightbox);
        return lightbox;
    }

    loadGalleryImages() {
        this.images = Array.from(document.querySelectorAll('.gallery-item'));
        this.images.forEach((image, index) => {
            image.dataset.index = index;
            image.addEventListener('click', () => this.openLightbox(index));
        });
    }

    bindEvents() {
        this.lightbox.querySelector('.close-lightbox').addEventListener('click', () => this.closeLightbox());
        this.lightbox.querySelector('.prev-image').addEventListener('click', () => this.prevImage());
        this.lightbox.querySelector('.next-image').addEventListener('click', () => this.nextImage());
        
        document.addEventListener('keydown', (e) => {
            if (this.lightbox.classList.contains('active')) {
                if (e.key === 'Escape') this.closeLightbox();
                if (e.key === 'ArrowLeft') this.prevImage();
                if (e.key === 'ArrowRight') this.nextImage();
            }
        });
    }

    setupFilters() {
        const filters = document.querySelectorAll('.gallery-filter');
        filters.forEach(filter => {
            filter.addEventListener('click', () => {
                const category = filter.dataset.category;
                this.filterImages(category);
                filters.forEach(f => f.classList.remove('active'));
                filter.classList.add('active');
            });
        });
    }

    filterImages(category) {
        this.images.forEach(image => {
            if (category === 'all' || image.dataset.category === category) {
                image.style.display = 'block';
            } else {
                image.style.display = 'none';
            }
        });
    }

    openLightbox(index) {
        this.currentIndex = index;
        this.lightbox.classList.add('active');
        this.updateLightboxImage();
        document.body.style.overflow = 'hidden';
    }

    closeLightbox() {
        this.lightbox.classList.remove('active');
        document.body.style.overflow = '';
    }

    updateLightboxImage() {
        const image = this.images[this.currentIndex];
        const lightboxImg = this.lightbox.querySelector('img');
        const caption = this.lightbox.querySelector('.lightbox-caption');
        const counter = this.lightbox.querySelector('.lightbox-counter');

        lightboxImg.src = image.querySelector('img').src;
        caption.textContent = image.dataset.caption || '';
        counter.textContent = `${this.currentIndex + 1} / ${this.images.length}`;
    }

    prevImage() {
        this.currentIndex = (this.currentIndex - 1 + this.images.length) % this.images.length;
        this.updateLightboxImage();
    }

    nextImage() {
        this.currentIndex = (this.currentIndex + 1) % this.images.length;
        this.updateLightboxImage();
    }
} 
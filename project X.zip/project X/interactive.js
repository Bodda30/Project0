// Gallery Lightbox
class GalleryLightbox {
    constructor() {
        this.init();
    }

    init() {
        this.createLightbox();
        this.bindEvents();
    }

    createLightbox() {
        const lightbox = document.createElement('div');
        lightbox.className = 'lightbox';
        lightbox.innerHTML = `
            <div class="lightbox-content">
                <button class="close-lightbox">×</button>
                <button class="prev-image">❮</button>
                <button class="next-image">❯</button>
                <img src="" alt="">
                <div class="lightbox-caption"></div>
            </div>
        `;
        document.body.appendChild(lightbox);
    }

    bindEvents() {
        document.querySelectorAll('.gallery-item').forEach(item => {
            item.addEventListener('click', () => this.openLightbox(item));
        });
    }

    openLightbox(item) {
        const lightbox = document.querySelector('.lightbox');
        const img = lightbox.querySelector('img');
        img.src = item.querySelector('img').src;
        lightbox.classList.add('active');
    }
}

// Car Rental Filter
class CarFilter {
    constructor() {
        this.bindEvents();
    }

    bindEvents() {
        const priceRange = document.getElementById('priceRange');
        const priceValue = document.getElementById('priceValue');
        
        priceRange.addEventListener('input', (e) => {
            priceValue.textContent = `$${e.target.value}/day`;
            this.filterCars();
        });
    }

    filterCars() {
        const type = document.getElementById('carTypeFilter').value;
        const price = document.getElementById('priceRange').value;
        
        document.querySelectorAll('.car-card').forEach(card => {
            const cardPrice = parseInt(card.querySelector('.price').textContent.slice(1));
            const cardType = card.dataset.category;
            
            const showCard = (type === 'all' || cardType === type) && 
                           cardPrice <= price;
            
            card.style.display = showCard ? 'block' : 'none';
        });
    }
}

// Initialize components
document.addEventListener('DOMContentLoaded', () => {
    new GalleryLightbox();
    new CarFilter();
}); 